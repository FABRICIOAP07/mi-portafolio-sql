var_entero = 12
x=var_entero + 23
print(x)


