print(5+6)
print(4-6)
print(5/1)
print(4*5)
print(5**2)
print(10%3)#el 1 es porque 3+3+3+"1" 