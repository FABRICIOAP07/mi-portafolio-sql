#Mejor de acceder a una lista de elementos de un listado
lenguajes=["python", "Ruby", "PHP", "Java"]

for lenguaje in lenguajes:
    print(lenguaje)
    
i=0
while i <= len (lenguajes):
    print(lenguajes[i])
    i=i+1