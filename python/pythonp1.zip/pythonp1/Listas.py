lenguajes=["python", "Ruby", "PHP", "Java"]
print(lenguajes[1])
lenguajes[1]="Go"
print(lenguajes)
print(lenguajes[-3])
print(lenguajes[1:3])
print(lenguajes[:3])