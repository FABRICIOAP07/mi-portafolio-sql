# nota de aprobacion de un alumno
puntaje=98
#intentacion o intentation es sangrado
if puntaje >=95:
    print("aprobado con honores1")
elif puntaje>=50:
    print("alumno aprobado")
else:# el else es en caso los 2 no se ejecuten 
    print("reprobado")
    
print("fuera del if")
    