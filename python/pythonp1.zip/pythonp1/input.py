# I N P U T nos permite obtener datos del usuario
resultado= input("ingresa tu edad:")
print(type(resultado))
numero=  int(resultado)
print(numero+2)