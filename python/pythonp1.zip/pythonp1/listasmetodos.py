lenguajes=["python", "Ruby", "PHP", "Java"]
lenguajes.insert(3,"Go")
lenguajes.insert(0, "C")
lenguajes.remove("Ruby")
print("PHP" in lenguajes)
lenguajes.clear()

print(len(lenguajes))