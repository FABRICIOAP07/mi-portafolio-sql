n1=2
n2=4
print(n1<n2)
print(n1>n2)
print(n1<=10)