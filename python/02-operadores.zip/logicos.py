edad= 12
print(edad>18 and edad<25)
print(edad>18 or edad<25) # or es evaluar uno o otro el de la derecha o el de la izquierda
print(not edad>17)