--la clausula having se utiliza cuando la clave no se puede utilizar en funciones agregadas
select count(age) from hello_sql.users having  count(age) > 0 ;