select * from users ORDER BY age;

select * from hello_sql.users order by age desc;

select name from hello_sql.users where email='sara@gmail.com' order by age desc;
