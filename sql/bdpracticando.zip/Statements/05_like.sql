SELECT * FROM hello_sql.users where email like '%gmail.com';

SELECT * FROM hello_sql.users where email like '%@%'