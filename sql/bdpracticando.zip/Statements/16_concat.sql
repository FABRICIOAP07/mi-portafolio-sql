select concat(name,' ', surname) from hello_sql.users;
