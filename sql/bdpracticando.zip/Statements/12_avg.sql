select avg(age) from hello_sql.users;
--media de sus edades de mi base de datos es _______

