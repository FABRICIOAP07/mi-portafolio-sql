select * from hello_sql.users where email is null;

select * from hello_sql.users where email is not null;

select * from hello_sql.users where email is not null and age=15;

select name, surname, ifnull(age, 0) as age from hello_sql.users;