--comentario en una linea

/*
este 
es un 
un
comentario
en varias 
lineas
*/