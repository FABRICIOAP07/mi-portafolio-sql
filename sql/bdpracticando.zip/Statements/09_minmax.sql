select max(age) from hello_sql.users;

select min(age) from hello_sql.users;