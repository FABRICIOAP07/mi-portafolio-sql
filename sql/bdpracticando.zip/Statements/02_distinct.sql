SELECT distinct * from hello_sql.users;

SELECT distinct age from hello_sql.users;

