select * from hello_sql.users where	name in ('Brais');

select * from hello_sql.users where	name in ('Brais', 'sara');

