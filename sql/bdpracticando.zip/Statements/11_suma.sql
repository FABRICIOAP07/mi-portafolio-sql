select sum(age) from hello_sql.users;

