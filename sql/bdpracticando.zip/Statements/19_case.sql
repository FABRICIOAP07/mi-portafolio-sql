select *,
case
	when age > 17 then 'Es mayor de edad'
    else 'es menor de edad'
end as agetext
from hello_sql.users
--otra forma
select *,
case
	when age > 17 then true
    else false
end as '¿es mayor de edad?'
from hello_sql.users