select name, init_date as 'Fecha de inicio en programacion' from hello_sql.users where age between 20 and 30;

select name, init_date as 'Fecha de inicio en programacion' from hello_sql.users where name ='brais' ;

