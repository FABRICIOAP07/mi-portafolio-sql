select count(*) from hello_sql.users;

select count(age) from hello_sql.users;

