SELECT * FROM users;

SELECT name FROM users;

SELECT user_id, name FROM users;
