select * from hello_sql.users limit 2;

select * from hello_sql.users where not email='sara@gmail.com' or age =15 limit 2;