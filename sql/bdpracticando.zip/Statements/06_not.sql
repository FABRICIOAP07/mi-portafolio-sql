select * from hello_sql.users where not email='sara@gmail.com';

select * from hello_sql.users where not email='sara@gmail.com' and age=15;

select * from hello_sql.users where not email='sara@gmail.com' or age=15;