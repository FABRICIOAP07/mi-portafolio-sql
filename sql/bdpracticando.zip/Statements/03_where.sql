SELECT * FROM hello_sql.users where age =15;

SELECT distinct age from hello_sql.users where age =15;