select max(age) from hello_sql.users group by age;

select count(age) from hello_sql.users group by age;

select count(age) age from hello_sql.users group by age order by age asc;

select count(age) , age from hello_sql.users where age > 15 group by age order by age asc;
